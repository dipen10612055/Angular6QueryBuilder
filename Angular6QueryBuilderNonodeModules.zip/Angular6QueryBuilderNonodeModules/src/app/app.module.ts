import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { QueryBuilderModule } from "angular2-query-builder";

import { AppComponent } from './app.component';

@NgModule({
  imports:      [BrowserModule, QueryBuilderModule],
  declarations: [AppComponent],
  //Added Providers from 6
  providers: [],
  bootstrap:    [AppComponent]
})
export class AppModule { }